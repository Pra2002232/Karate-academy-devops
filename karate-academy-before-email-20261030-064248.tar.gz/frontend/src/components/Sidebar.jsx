import { NavLink } from "react-router-dom";
import LogoutButton from "./LogoutButton";


const icons = {
    dashboard: (
        <svg viewBox="0 0 24 24">
            <rect x="3" y="3" width="7" height="7" rx="1.5" />
            <rect x="14" y="3" width="7" height="7" rx="1.5" />
            <rect x="3" y="14" width="7" height="7" rx="1.5" />
            <rect x="14" y="14" width="7" height="7" rx="1.5" />
        </svg>
    ),

    students: (
        <svg viewBox="0 0 24 24">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
    ),

    attendance: (
        <svg viewBox="0 0 24 24">
            <rect x="3" y="4" width="18" height="17" rx="2" />
            <path d="M16 2v4M8 2v4M3 10h18" />
            <path d="m8 15 2 2 5-5" />
        </svg>
    ),

    fees: (
        <svg viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="9" />
            <path d="M15 8.5c-.7-.7-1.7-1-3-1-1.7 0-3 .8-3 2s1.2 2 3 2 3 .8 3 2-1.3 2-3 2c-1.3 0-2.3-.3-3-1" />
            <path d="M12 5.5v2M12 16.5v2" />
        </svg>
    ),

    belt: (
        <svg viewBox="0 0 24 24">
            <path d="M3 7h18v4H3z" />
            <path d="M7 11v10M17 11v10" />
            <path d="M7 16h10" />
        </svg>
    ),

    competitions: (
        <svg viewBox="0 0 24 24">
            <path d="M8 21h8" />
            <path d="M12 17v4" />
            <path d="M7 4h10v5a5 5 0 0 1-10 0V4Z" />
            <path d="M7 6H4a1 1 0 0 0-1 1v1a4 4 0 0 0 4 4M17 6h3a1 1 0 0 1 1 1v1a4 4 0 0 1-4 4" />
            <path d="M9 2h6" />
        </svg>
    ),

    results: (
        <svg viewBox="0 0 24 24">
            <path d="M8 21h8" />
            <path d="M12 17v4" />
            <path d="M6 3h12v8a6 6 0 0 1-12 0V3Z" />
            <path d="M9 7h6M9 10h6" />
        </svg>
    ),

    reports: (
        <svg viewBox="0 0 24 24">
            <path d="M4 19V5" />
            <path d="M4 19h17" />
            <path d="M8 16v-5M12 16V7M16 16v-8M20 16v-4" />
        </svg>
    ),

    messages: (
        <svg viewBox="0 0 24 24">
            <path d="M20 11.5a8 8 0 0 1-8 8 8.5 8.5 0 0 1-4-.9L3 20l1.4-4.2A8 8 0 1 1 20 11.5Z" />
            <path d="M8 12h.01M12 12h.01M16 12h.01" />
        </svg>
    ),

    settings: (
        <svg viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.8 1.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-2.6V20a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1-1.8-1.8.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H6v-2.6h.2a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1 1.8-1.8.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6V5h2.6v.2a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1 1.8 1.8-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v2.6H21a1.7 1.7 0 0 0-1.6 1Z" />
        </svg>
    )
};

const menuSections = [
    {
        title: "MAIN",
        items: [
            { to: "/", label: "Dashboard", icon: icons.dashboard, end: true },
            { to: "/students", label: "Students", icon: icons.students },
            { to: "/attendance", label: "Attendance", icon: icons.attendance }
        ]
    },
    {
        title: "ACADEMY",
        items: [
            { to: "/fees", label: "Fees Management", icon: icons.fees },
            { to: "/belts", label: "Belt & Grades", icon: icons.belt },
            { to: "/competitions", label: "Competitions", icon: icons.competitions },
            { to: "/results", label: "Results & Winners", icon: icons.results }
        ]
    },
    {
        title: "COMMUNICATION",
        items: [
            { to: "/messages", label: "Messages", icon: icons.messages }
        ]
    },
    {
        title: "ANALYTICS",
        items: [
            { to: "/reports", label: "Reports", icon: icons.reports }
        ]
    }
];


const sidebarUser =
    JSON.parse(
        localStorage.getItem("admin_user") || "null"
    );

const sidebarUserRole =
    sidebarUser?.role || "SUPER_ADMIN";


const canViewSidebarItem = (label) => {

    if (sidebarUserRole === "SUPER_ADMIN") {
        return true;
    }

    if (sidebarUserRole === "BRANCH_ADMIN") {

        return [
            "Dashboard",
            "Students",
            "Attendance",
            "Fees Management",
            "Belt & Grades",
            "Competitions",
            "Results & Winners",
            "Reports",
            "Messages",
            "Settings"
        ].includes(label);

    }

    if (sidebarUserRole === "PARENT") {

        return [
            "Dashboard"
        ].includes(label);

    }

    return false;
};


function Sidebar() {
    return (
        <aside className="sidebar">
            <div className="sidebar-brand">
                <div className="brand-symbol">
                    <span>拳</span>
                </div>

                <div className="brand-content">
                    <div className="brand-name">KARATE</div>
                    <div className="brand-academy">ACADEMY</div>
                </div>
            </div>

            <div className="brand-tagline">
                <span></span>
                Management System
            </div>

            <nav className="sidebar-navigation">
                {menuSections.map((section) => (
                    <div className="menu-section" key={section.title}>
                        <div className="menu-section-title">
                            {section.title}
                        </div>

                        {section.items.filter(item => canViewSidebarItem(item.label)).map((item) => (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                end={item.end}
                                className={({ isActive }) =>
                                    `sidebar-link ${isActive ? "active" : ""}`
                                }
                            >
                                <span className="sidebar-icon">
                                    {item.icon}
                                </span>

                                <span className="sidebar-label">
                                    {item.label}
                                </span>
                            </NavLink>
                        ))}
                    </div>
                ))}
            </nav>
<div className="sidebar-bottom">


                {JSON.parse(localStorage.getItem("admin_user") || "null")?.role === "SUPER_ADMIN" && (


                <NavLink
                    to="/admin-management"
                    className={({ isActive }) =>
                        `sidebar-link ${isActive ? "active" : ""}`
                    }
                >
                    <span className="sidebar-icon">👥</span>
                    <span className="sidebar-label">
                        User Management
                    </span>
                </NavLink>


                )}

                {sidebarUserRole === "SUPER_ADMIN" && (
                <NavLink
                    to="/settings"
                    className={({ isActive }) =>
                        `sidebar-link settings-link ${isActive ? "active" : ""}`
                    }
                >
                    <span className="sidebar-icon">
                        {icons.settings}
                    </span>
                    <span className="sidebar-label">
                        Settings
                    </span>
                </NavLink>
                )}

                <div className="admin-card">
                    <div className="admin-avatar">
                        A
                    </div>

                    <div className="admin-details">
                        <div className="admin-name">
                            Academy Admin
                        </div>
                        <div className="admin-role">
                            Administrator
                        </div>
                    </div>

                    <div className="admin-status"></div>
                </div>

                <div className="sidebar-version">
                    Karate Academy <span>v1.0</span>
                </div>
                <LogoutButton />
            </div>


            </aside>
        );
};

export default Sidebar;
